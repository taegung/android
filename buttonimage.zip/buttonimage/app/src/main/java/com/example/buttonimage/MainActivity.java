package com.example.buttonimage;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
/* **********************************************
 * 프로젝트명 :  button image
 * 작성자 : 2019038059 윤태경
 * 작성일 : 2022.04.02
 *프로그램 설명 : 버튼에도 이미지를 추가하고 버튼을 클릭하면 이미지가 10도씩 회전하는 프로그램
 ************************************************/
public class MainActivity extends AppCompatActivity {
    float x;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button=findViewById(R.id.button);
        ImageView imageView= findViewById(R.id.image);

        button.setOnClickListener(new CheckBox.OnClickListener() {
            @Override
            public void onClick(View v) {
                x =imageView.getRotation();
                x=(x+10)%360;
                imageView.setRotation(x);
            }
        }) ;
    }
}